import React, {Component} from 'react';
import classes from './CurrentWeather.module.css'

class currentWeather extends Component {
    render(){
        console.log(this.props)
        const images = require.context('../../assets/images/weatherIcons', true);
    
            let forecastHour
            if (this.props.cityLoaded) {
                let img = images('./' + this.props.currentCityWeather_0.icon + '@2x.png');
                forecastHour = <div className={classes.wrapper}>
                    <div className={classes.currentWeather}>
                        <div>City name: {this.props.currentCityName}</div>
                        <div>Country: {this.props.currentCityCountry}</div>
                        <div>Temp: {this.props.CityWeatherMain.temp}</div>
    
                        <div>
                            <img src={img} alt='logo'/>
                        </div>
    
                        <div>Temp Feels Like: {this.props.CityWeatherMain.feels_like}</div>
                        <div>Temp Min: {this.props.CityWeatherMain.temp_min}</div>
                        <div>Temp Max: {this.props.CityWeatherMain.temp_max}</div>
                        <div>Pressure: {this.props.CityWeatherMain.pressure}</div>
                        <div>Wind speed: {this.props.CityWeatherWind.speed}</div>
                        <div>Clouds: {this.props.CityWeatherClound.all}</div>
                    </div>
                </div>
            }else{
                forecastHour = <p className={classes.wrapper}>Please choose city</p>
            }
        return (
            forecastHour
        )
    }
}

export default currentWeather