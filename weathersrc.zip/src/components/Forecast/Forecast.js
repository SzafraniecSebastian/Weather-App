import React, {Component} from 'react';
import ForecastHour from '../Forecast/ForecastHour/ForecastHour';
import Aux from '../../HOC/Aux/Aux';
import classes from './Forecast.module.css'

class forecast extends Component{
    
    render (){
        console.log(this.props)
        let forecastHour
        if (this.props.cityLoaded) {
            forecastHour = this.props.CityForecastDataList
                .map((hour) => {
                return <ForecastHour 
                            hour={hour.dt_txt}
                            temp={hour.main.temp}
                            feelsLike={hour.main.feels_like}
                            pressure={hour.main.pressure}
                            clouds={hour.clouds.all}
                            icon={hour.weather[0].icon}/>
                })
            }else{
                forecastHour = <p>Please choose city</p>
            }
        
        return(
            <div className={classes.forecastDaysContainer}>
                {forecastHour}
            </div>
        )
    }
    
}

export default forecast