import React from 'react';
import classes from './ForecastHour.module.css'

const forecastDay = (props) => {
    console.log(props.icon)
    const images = require.context('../../../assets/images/weatherIcons', true);
    let img = images('./' + props.icon + '@2x.png');

    return(
        <div className={classes.wrapper}>
            <div>Date : {props.hour}</div>
            <div>Temp : {props.temp} C </div>
            <div>Feels Like : {props.feelsLike} C </div>
            <div>Pressure : {props.pressure} hpa </div>
            <div>Clouds : {props.clouds} % </div>
            <div>                            
                <img src={img} alt='logo'/>
            </div>
        </div>
    )
    
}

export default forecastDay