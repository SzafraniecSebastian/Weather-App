import React from 'react';
import classes from './Layout.module.css';
import Aux from '../../HOC/Aux/Aux';
import WeatherData from '../../containers/WeatherData/WeatherData';
import { BrowserRouter } from 'react-router-dom';



const Layout = (props) => {


    return (
        <BrowserRouter>
            <WeatherData/>
        </BrowserRouter>
    )
}

export default Layout



