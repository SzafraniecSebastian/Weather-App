import React from 'react';
import Logo from '../../assets/images/Logo.png';

import classes from './Logo.module.css'

const logo = (props) => {
    const images = require.context('../../assets/images/weatherIcons', true);
    // let img = images('./' + props.imageName);
    let img = images('./' + '02wn' + '@2x.png');
    return(
        <div className={classes.logo}>
            <img src={img} alt='logo'/>
        </div>
    )
 
}

export default logo