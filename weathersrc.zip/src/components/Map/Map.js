import React from 'react';

const map = () => (
    <img/>
)

export default map