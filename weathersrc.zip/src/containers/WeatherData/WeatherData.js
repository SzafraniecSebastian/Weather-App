import React ,{Component} from 'react';
import Aux from '../../HOC/Aux/Aux';
import axios from '../../axiosCities';
import { Route, NavLink } from 'react-router-dom';
import Toolbar from '../../components/Toolbar/Toolbar';
import CurrentWeather from '../../components/CurrentWeather/CurrentWeather';
import Forecast from '../../components/Forecast/Forecast';
import classes from './WeatherData.module.css'

class weatherData extends Component {
    state = {
        firstLoad: false,
        cityLoaded: false,
        city: 'Krakow',
        appiID: "18d9b5fdd7ac2bdc79bb81c207b7a7ec",
        currentCityName: '',
        currentCityCountry: '',
        CityWeatherMain: '',
        CityWeatherWind: '',
        CityWeatherClound: '',
        CityForecastDataList: '',
        currentCityWeather_0: '',
    }

    // constructor(){
        
    // }

//    componentDidMount (){
//        if(!this.state.firstLoad){
//            this.getCityWeather()
//            this.setState({firstLoad: true})
//        }
//    }

// getCityWeather = (event) => {
//     event.preventDefault();
//     const baseUrl = 'https://api.openweathermap.org/data/2.5';
    
//     const { city, appiID } = this.state;
//     const urls = [
//       `${baseUrl}/weather?q=${city}&units=metric&appid=${appiID}`,
//       `${baseUrl}/forecast?q=${city}&units=metric&appid=${appiID}`
//     ];
//     let promises = urls.map(s => axios.get(s),
    
//     Promise.all(promises)
//       .then(([weatherResponse, forecastResponse]) => {
//         const {
//           date: {
//             weather,
//             name,
//             sys: { country },
//             main,
//             wind,
//             clouds
//           },
//         } = weatherResponse;
        
//         const {
//           data: { list },
//         } = forecastResponse;
  
//         this.setState({
//           currentCityWeather: weather,
//           currentCityName: name,
//           currentCityCountry: country,
//           CityWeatherMain: main,
//           CityWeatherWind: wind,
//           CityWeatherClound: clouds,
//           CityForecastDataList: list,
//           cityLoaded: true,
//         });
//       })
//       .catch(({ message }) => {
//         console.error(message);
//       })
//     )}

getCityWeather = (event) => {
    event.preventDefault()
    axios
        .get('https://api.openweathermap.org/data/2.5/forecast?q=' + this.state.city +'&units=metric&appid=' + this.state.appiID)
        .then(forecast => {
            console.log('pobieramy forecat: ')
            console.log(forecast)
            this.setState({
                CityForecastDataList: forecast.data.list,
            })        
            return axios.get('https://api.openweathermap.org/data/2.5/weather?q=' + this.state.city +'&units=metric&appid=' + this.state.appiID);
        })
        .then(weather => {
            console.log('pobieramy weather:')
            console.log(weather)
            this.setState({
                currentCityWeather_0: weather.data.weather[0],
                currentCityName: weather.data.name,
                currentCityCountry: weather.data.sys.country,
                CityWeatherMain: weather.data.main,
                CityWeatherWind: weather.data.wind,
                CityWeatherClound: weather.data.clouds
            })
            return axios.get('https://tile.openweathermap.org/map/clouds_new/10/19/50.png?appid=18d9b5fdd7ac2bdc79bb81c207b7a7ec')
                
        })
        .then(map => {
            console.log('pobieramy map:')
            this.setState({
                cityMap: map,
                cityLoaded: true
            })
            console.log(this.state.cityMap)
        }).catch(error => console.log(error.response));
}

    // getCityWeather = (event) => {
    //     event.preventDefault()
    //     axios
    //         .get('https://api.openweathermap.org/data/2.5/weather?q=' + this.state.city +'&units=metric&appid=' + this.state.appiID)
    //         .then(weather => {
    //             console.log(weather.data)
    //             this.setState({
    //                 currentCityWeather: weather.data.weather,
    //                 currentCityName: weather.data.name,
    //                 currentCityCountry: weather.data.sys.country,
    //                 CityWeatherMain: weather.data.main,
    //                 CityWeatherWind: weather.data.wind,
    //                 CityWeatherClound: weather.data.clouds,
    //                 cityLoaded: true
    //             })        
    //             return axios.get('https://api.openweathermap.org/data/2.5/forecast?q=' + this.state.city +'&units=metric&appid=' + this.state.appiID);
    //         })
    //         .then(forecast => {
    //             console.log(forecast.data)
    //             this.setState({
    //                 CityForecastDataList: forecast.data.list,
    //                 cityLoaded: true
    //             })
    //         }).catch(error => console.log(error.response));
    // }

    // getCityWeather = (event) => {
    //     event.preventDefault() ;    
    //     axios.all([axios.get('https://api.openweathermap.org/data/2.5/weather?q=' + this.state.city +'&units=metric&appid=' + this.state.appiID),
    //        axios.get('https://api.openweathermap.org/data/2.5/forecast?q=' + this.state.city +'&units=metric&appid=' + this.state.appiID)])
    //             .then(axios.spread((firstResponse, secondResponse) => {  
    //                  console.log(firstResponse.data,secondResponse.data);
    //  }))
    //  .catch(error => console.log(error));
    // }

    // getCityWeather = (event) => {
    //     axios.get('https://api.openweathermap.org/data/2.5/weather?q=' + this.state.city +'&units=metric&appid=' + this.state.appiID)
    //         .then( weather => {
    //             console.log(weather)
    //             this.setState({
    //                 currentCityWeather: weather.data.weather,
    //                 currentCityName: weather.data.name,
    //                 currentCityCountry: weather.data.sys.country,
    //                 CityWeatherMain: weather.data.main,
    //                 CityWeatherWind: weather.data.wind,
    //                 CityWeatherClound: weather.data.clouds,
    //                 cityLoaded: true
    //             })           
    //         }
    //         ).catch( error => {
    //             console.log(error)
    //         })        


    //     axios.get('https://api.openweathermap.org/data/2.5/forecast?q=' + this.state.city +'&units=metric&appid=' + this.state.appiID)
    //         .then( forecast => {
    //             console.log(forecast)
    //             this.setState({
    //                 CityForecastDataList: forecast.data.list,
    //                 cityLoaded: true
    //             })
    //         }).catch( error => {
    //             console.log(error)
    //         })   
    //     event.preventDefault()     
    // }

    handleChangeCity = (event) => {
        this.setState({city: event.target.value})
    }

    render () {
        return (

            <Aux className={classes.weatherDataWrapper}>
                <div className={classes.weatherDataWrapper}>
                <Toolbar/>

                <div className={classes.topHeader}>
                    <form>
                        <label className={classes.input}>
                            <input type='text' value={this.state.city} onChange={this.handleChangeCity}></input>
                        </label>
                        <button className={classes.submitBtn} type='submit' value='submit' onClick={this.getCityWeather}>Button</button>
                    </form>

                    <header className={classes.menu}>
                        <nav>
                            <ul>
                                <li><NavLink to="/" exact>Current Weather</NavLink></li>
                                <li><NavLink to="/forecast" exact>5 days forecast</NavLink></li>
                            </ul>
                        </nav>
                    </header>
                </div>
                    
                    <Route 
                        path="/" exact 
                        render={(props) => <CurrentWeather 
                            {...props} 
                            cityLoaded={this.state.cityLoaded}
                            currentCityWeather_0={this.state.currentCityWeather_0}
                            currentCityName={this.state.currentCityName}
                            currentCityCountry={this.state.currentCityCountry}
                            CityWeatherMain={this.state.CityWeatherMain}
                            CityWeatherWind={this.state.CityWeatherWind}
                            CityWeatherClound={this.state.CityWeatherClound}/>}
                    />

                    <Route 
                        path="/forecast"  
                        render={(props) => <Forecast 
                            {...props}
                            cityLoaded={this.state.cityLoaded} 
                            CityForecastDataList={this.state.CityForecastDataList} />}
                    />
                </div>
            </Aux>
        )
    }
}

export default weatherData